import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { NoCodeBlock, NoCodeAppearance } from '../lib/nocode_store';
import { GoogleGenAI } from '@google/genai';
import { useSettings } from '../contexts/SettingsContext';
import { useAppContext } from '../store';
import { audioService } from '../utils/audio';
import { 
  Sparkles, Keyboard, Award, CheckCircle2, 
  HelpCircle, ChevronDown, MessageSquare, Play, 
  Check, PlayCircle, Star, Award as BadgeIcon 
} from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import remarkBreaks from 'remark-breaks';

interface NoCodeRendererProps {
  blocks: NoCodeBlock[];
  appearance: NoCodeAppearance;
  isLiveEditing?: boolean;
  onBlockUpdate?: (blockId: string, updatedBlock: Partial<NoCodeBlock>) => void;
  onAddBlockClick?: (insertIndex: number) => void;
  onMoveBlock?: (id: string, direction: 'up' | 'down') => void;
  onDeleteBlock?: (id: string) => void;
}

export function NoCodeRenderer({
  blocks,
  appearance,
  isLiveEditing = false,
  onBlockUpdate,
  onAddBlockClick,
  onMoveBlock,
  onDeleteBlock
}: NoCodeRendererProps) {
  const { geminiApiKey } = useSettings();
  const { login, authUser, setView } = useAppContext();

  const handleRegisterClick = () => {
    audioService.playClick();
    if (!authUser) {
      login();
    } else {
      setView('roadmap');
    }
  };

  // AI block state
  const [aiPrompt, setAiPrompt] = useState('');
  const [aiResponse, setAiResponse] = useState('');
  const [aiLoading, setAiLoading] = useState(false);

  // Quiz state: blockId -> active index answer
  const [quizAnswers, setQuizAnswers] = useState<Record<string, Record<number, number>>>({});
  const [quizFeedback, setQuizFeedback] = useState<Record<string, Record<number, string>>>({});

  // Game state: blockId -> answer input string
  const [gameInputs, setGameInputs] = useState<Record<string, string>>({});
  const [gameSuccess, setGameSuccess] = useState<Record<string, boolean>>({});

  // FAQ open states: blockId-index -> boolean
  const [faqOpen, setFaqOpen] = useState<Record<string, boolean>>({});

  // Styles computed from appearance settings
  const fontClass = 
    appearance.fontFamily === 'mono' ? 'font-mono' :
    appearance.fontFamily === 'serif' ? 'font-serif' :
    appearance.fontFamily === 'grotesk' ? 'font-sans tracking-tight' : 
    (appearance.fontFamily && !['sans', 'mono', 'serif', 'grotesk'].includes(appearance.fontFamily)) ? '' : 'font-sans';

  const customFontStyle = (appearance.fontFamily && !['sans', 'mono', 'serif', 'grotesk'].includes(appearance.fontFamily))
    ? { fontFamily: `"${appearance.fontFamily}", sans-serif` }
    : {};

  const sizeClass = 
    appearance.fontSize === 'sm' ? 'text-sm' :
    appearance.fontSize === 'lg' ? 'text-lg' :
    appearance.fontSize === 'xl' ? 'text-xl' :
    appearance.fontSize === '2xl' ? 'text-2xl' : 'text-base';
  
  const rootStyle = {
    ...customFontStyle,
    ...(appearance.customFontUrl ? { '--custom-font-url': `url(${appearance.customFontUrl})` } as any : {}),
    zoom: appearance.fontScale ? `${appearance.fontScale}%` : '100%'
  };

  const roundClass = 
    appearance.borderRadius === 'none' ? 'rounded-none' :
    appearance.borderRadius === 'sm' ? 'rounded-sm' :
    appearance.borderRadius === 'md' ? 'rounded-md' :
    appearance.borderRadius === 'lg' ? 'rounded-lg' : 'rounded-3xl';

  const pYClass = 
    appearance.spacing === 'compact' ? 'py-8' :
    appearance.spacing === 'spacious' ? 'py-20' : 'py-14';

  // Handler for Live Inline Editing of elements
  const handleTextChange = (blockId: string, field: keyof NoCodeBlock, value: string) => {
    if (onBlockUpdate) {
      onBlockUpdate(blockId, { [field]: value });
    }
  };

  const handleTestimonialChange = (blockId: string, block: NoCodeBlock, index: number, field: string, value: any) => {
    if (!onBlockUpdate || !block.testimonials) return;
    const items = [...block.testimonials];
    items[index] = { ...items[index], [field]: value };
    onBlockUpdate(blockId, { testimonials: items });
  };

  const handleFAQChange = (blockId: string, block: NoCodeBlock, index: number, field: string, value: any) => {
    if (!onBlockUpdate || !block.faqItems) return;
    const items = [...block.faqItems];
    items[index] = { ...items[index], [field]: value };
    onBlockUpdate(blockId, { faqItems: items });
  };

  const handlePricingChange = (blockId: string, block: NoCodeBlock, index: number, field: string, value: any) => {
    if (!onBlockUpdate || !block.pricingTiers) return;
    const items = [...block.pricingTiers];
    items[index] = { ...items[index], [field]: value };
    onBlockUpdate(blockId, { pricingTiers: items });
  };

  // Run mock AI request (using gemini if key is available, or fall back immediately to an epic helpful simulated AI reply)
  const runAISample = async (promptText: string) => {
    if (!promptText.trim()) return;
    audioService.playClick();
    setAiLoading(true);
    setAiResponse('');
    setAiPrompt('');
    
    try {
      // Create real request to server API endpoint with current settings
      const response = await fetch('/api/tutor', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          ...(geminiApiKey ? { 'X-Gemini-API-Key': geminiApiKey } : {})
        },
        body: JSON.stringify({
          studentMessage: promptText,
          context: 'Trợ lý học lập trình Tuyệt Đỉnh (Home AI Block)',
          level: 'Lớp 10 - 12'
        })
      });

      const data = await response.json();
      const replyText = data.reply || '';

      if (replyText) {
        // Stream the live response beautifully word by word / char by char
        let written = '';
        for (let i = 0; i < replyText.length; i += 4) {
          written += replyText.substring(i, i + 4);
          setAiResponse(written);
          await new Promise(r => setTimeout(r, 8));
        }
      } else {
        throw new Error('Nút thắt kết nối');
      }
    } catch (e) {
      // Safe, educational curated offline response simulator fallback
      const replies = [
        `Xin chào! Rất tuyệt khi được hỗ trợ bạn học Python. Về câu hỏi của bạn, đây là ví dụ mã nguồn cực kỳ dễ hiểu:

\`\`\`python
# Khai báo một danh sách (list)
mon_hoc = ["Toán", "Văn", "Tin Học 10"]

# Thêm môn Python vào danh sách
mon_hoc.append("Lập Trình Python 🐍")

# Dùng vòng lặp in ra màn hình
for mon in mon_hoc:
    print("Tôi yêu thích học môn:", mon)
\`\`\`

Bạn có thể chạy thử đoạn mã trên ngay trong mục **Thực hành** của Pilearn đấy! Hãy ghi nhớ phím tắt \`Ctrl+Enter\` để tối ưu tốc độ sấm sét nhé!`,
        `Tuyệt vời! Hàm \`print()\` trong Python dùng để in dữ liệu ra cửa sổ màn hình (Terminal). Ví dụ:
\`\`\`python
ten = "Pilearn"
tuoi = 16
print(f"Chào bạn, tôi là {ten}, năm nay tôi {tuoi} tuổi!")
\`\`\`
Dấu \`f\` trước chuỗi viết tắt cho "Formatted string", giúp gắn các biến trực tiếp vào chuỗi văn bản vô cùng gọn gàng!`,
        `Thầy cô giáo và học sinh thường nhầm lẫn giữa vòng lặp \`for\` và \`while\`:
- \`for\`: Dùng khi biết trước số lần lặp (ví dụ lặp qua danh sách 5 bài học).
- \`while\`: Dùng khi muốn lặp liên tục cho tới khi một điều kiện sai đi (ví dụ game chạy đến khi người dùng chọn thoát).`
      ];
      // Random response
      const chosen = replies[Math.floor(Math.random() * replies.length)];
      
      let written = '';
      for (let i = 0; i < chosen.length; i += 4) {
        written += chosen.substring(i, i + 4);
        setAiResponse(written);
        await new Promise(r => setTimeout(r, 10));
      }
    } finally {
      setAiLoading(false);
    }
  };

  return (
    <div className={`w-full ${fontClass} ${sizeClass} transition-all`} style={rootStyle}>
      {appearance.customFontUrl && (
        <style dangerouslySetInnerHTML={{ __html: `@import url('${appearance.customFontUrl}');` }} />
      )}
      {blocks.map((block, idx) => {
        const isLastBlock = idx === blocks.length - 1;

        return (
          <div key={block.id} className="relative group/block border-y border-transparent hover:border-blue-300/40 transition-colors">
            {/* Admin Block overlay settings */}
            {isLiveEditing && (
              <div className="absolute top-2 right-4 z-40 bg-slate-900/90 text-white text-[10px] font-bold py-1.5 px-3 rounded-full flex items-center gap-2 shadow-lg backdrop-blur-md opacity-30 group-hover/block:opacity-100 transition-opacity">
                <span className="uppercase text-blue-400">{block.type}</span>
                <div className="h-3 w-px bg-slate-700" />
                <button 
                  onClick={() => onMoveBlock && onMoveBlock(block.id, 'up')}
                  disabled={idx === 0}
                  className="hover:text-blue-300 disabled:opacity-30 cursor-pointer"
                  title="Di chuyển lên"
                >
                  ▲
                </button>
                <button 
                  onClick={() => onMoveBlock && onMoveBlock(block.id, 'down')}
                  disabled={isLastBlock}
                  className="hover:text-blue-300 disabled:opacity-30 cursor-pointer"
                  title="Di chuyển xuống"
                >
                  ▼
                </button>
                <button 
                  onClick={() => onDeleteBlock && onDeleteBlock(block.id)}
                  className="hover:text-red-400 text-red-300 cursor-pointer ml-1 font-bold"
                  title="Xóa block"
                >
                  Xóa
                </button>
              </div>
            )}

            {/* Block Body rendering wrapper */}
            <div className={`max-w-7xl mx-auto px-6 ${pYClass} relative`}>
              {/* 1. HERO BANNER BLOCK */}
              {block.type === 'banner' && (
                <div className={`flex flex-col lg:flex-row items-center justify-between gap-12`}>
                  <div className={`w-full lg:w-1/2 text-${block.align || 'left'} flex flex-col items-${block.align === 'center' ? 'center' : 'start'}`}>
                    <h1 
                      contentEditable={isLiveEditing}
                      suppressContentEditableWarning
                      onBlur={(e) => handleTextChange(block.id, 'title', e.currentTarget.innerText)}
                      className={`text-4xl md:text-5xl lg:text-6xl font-black text-slate-900 dark:text-white leading-tight mb-6 outline-none focus:bg-yellow-50 focus:text-slate-900 p-1 ${isLiveEditing ? 'border-2 border-dashed border-blue-400/60 rounded-xl cursor-text' : ''}`}
                    >
                      {block.title}
                    </h1>
                    
                    <p 
                      contentEditable={isLiveEditing}
                      suppressContentEditableWarning
                      onBlur={(e) => handleTextChange(block.id, 'subtitle', e.currentTarget.innerText)}
                      className="text-slate-600 dark:text-slate-350 text-base sm:text-lg font-medium leading-relaxed mb-8 outline-none focus:bg-yellow-50 focus:text-slate-900 p-1"
                    >
                      {block.subtitle}
                    </p>

                    <button 
                      onClick={handleRegisterClick}
                      className="bg-blue-600 hover:bg-blue-700 text-white font-bold text-sm px-8 py-4.5 rounded-full shadow-lg transition-transform hover:scale-[1.02]"
                    >
                      {block.buttonText || 'Bắt đầu'}
                    </button>
                  </div>

                  <div className="w-full lg:w-1/2 flex justify-center">
                    <div className="relative w-full max-w-[480px] aspect-[4/3] rounded-3xl overflow-hidden shadow-2xl border-4 border-white dark:border-slate-800 bg-slate-100">
                      <img 
                        src={block.imageUrl || 'https://images.unsplash.com/photo-1543269865-cbf427effbad?q=80&w=2070&auto=format&fit=crop'} 
                        alt="Banner illustration" 
                        className="w-full h-full object-cover"
                      />
                      {isLiveEditing && (
                        <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center text-white p-4 text-center">
                          <p className="text-xs font-bold mb-2">Quản lý nâng cao: Nhập URL ảnh ở thuộc tính</p>
                          <input 
                            type="text" 
                            placeholder="Nhập link ảnh (URL)..."
                            value={block.imageUrl || ''}
                            onChange={(e) => handleTextChange(block.id, 'imageUrl', e.target.value)}
                            className="bg-slate-800 text-white text-xs px-3 py-1.5 rounded-lg w-full max-w-sm border border-slate-700"
                          />
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              )}

              {/* 2. TEXT BLOCK (Markdown simulation) */}
              {block.type === 'text' && (
                <div className={`max-w-3xl mx-auto text-${block.align || 'left'}`}>
                  <h2 
                    contentEditable={isLiveEditing}
                    suppressContentEditableWarning
                    onBlur={(e) => handleTextChange(block.id, 'title', e.currentTarget.innerText)}
                    className="text-3xl font-extrabold text-slate-900 dark:text-white mb-6 outline-none focus:bg-yellow-50 focus:text-slate-900 p-1"
                  >
                    {block.title}
                  </h2>
                  <div 
                    className={`prose prose-blue dark:prose-invert text-slate-700 dark:text-slate-300 text-base sm:text-lg leading-relaxed outline-none p-2 border-2 ${isLiveEditing ? 'border-dashed border-blue-400 rounded-xl bg-yellow-50/50' : 'border-transparent'}`}
                  >
                    {isLiveEditing ? (
                      <textarea
                        value={block.content}
                        onChange={(e) => handleTextChange(block.id, 'content', e.target.value)}
                        className="w-full bg-transparent outline-none resize-none min-h-[120px] font-mono text-sm text-slate-900"
                        placeholder="Nhập nội dung (hỗ trợ Markdown)..."
                      />
                    ) : (
                      <ReactMarkdown remarkPlugins={[remarkGfm, remarkBreaks]} rehypePlugins={[rehypeRaw]}>
                        {block.content || ''}
                      </ReactMarkdown>
                    )}
                  </div>
                </div>
              )}

              {/* 3. SIMULATED VIDEO EMBED BLOCK */}
              {block.type === 'video' && (
                <div className="max-w-4xl mx-auto text-center space-y-6">
                  <h2 className="text-2xl font-bold">{block.title || 'Video Hướng Dẫn Kỹ Thuật'}</h2>
                  <div className="aspect-video w-full rounded-2xl overflow-hidden shadow-lg border-4 border-white dark:border-slate-800 bg-slate-950 flex flex-col items-center justify-center relative">
                    <PlayCircle className="w-16 h-16 text-blue-500 mb-2 cursor-pointer hover:scale-110 transition-transform" />
                    <span className="text-white font-bold text-sm">Xem Video Trực Quan Lớp Học Pilearn</span>
                    <span className="text-xs text-slate-500 mt-1">Simulated Embed Player</span>
                    {isLiveEditing && (
                      <div className="absolute inset-x-0 bottom-0 bg-slate-900/95 p-3 text-white flex items-center justify-between text-xs font-mono">
                        <span>Video URL:</span>
                        <input 
                          type="text" 
                          value={block.videoUrl || ''} 
                          placeholder="Nhập link Youtube embed..."
                          onChange={(e) => handleTextChange(block.id, 'videoUrl', e.target.value)}
                          className="bg-slate-800 px-3 py-1 rounded border border-slate-700 flex-1 ml-3"
                        />
                      </div>
                    )}
                  </div>
                </div>
              )}

              {/* 4. CALL TO ACTION (CTA) REGISTER BUTTON */}
              {block.type === 'cta' && (
                <div className={`p-8 sm:p-12 bg-blue-600 text-white rounded-[32px] shadow-xl text-center flex flex-col items-center max-w-4xl mx-auto overflow-hidden relative`}>
                  <div className="absolute -top-12 -right-12 w-32 h-32 bg-white/10 rounded-full blur-xl" />
                  <div className="absolute -bottom-10 -left-10 w-24 h-24 bg-white/10 rounded-full blur-xl" />
                  <h2 
                    contentEditable={isLiveEditing}
                    suppressContentEditableWarning
                    onBlur={(e) => handleTextChange(block.id, 'title', e.currentTarget.innerText)}
                    className="text-2xl sm:text-3xl font-black mb-4 outline-none"
                  >
                    {block.title || 'Tham gia học tập ngay hôm nay!'}
                  </h2>
                  <p 
                    contentEditable={isLiveEditing}
                    suppressContentEditableWarning
                    onBlur={(e) => handleTextChange(block.id, 'subtitle', e.currentTarget.innerText)}
                    className="text-white/80 max-w-lg mb-8 text-sm sm:text-base outline-none"
                  >
                    {block.subtitle || 'Nhận ngay 100 điểm khởi động để so tài cùng các học sinh Tin Học 10 cả vùng.'}
                  </p>
                  <button 
                    onClick={handleRegisterClick}
                    className="bg-white text-blue-600 font-extrabold text-sm sm:text-base px-8 py-3.5 rounded-full shadow-lg hover:scale-105 active:scale-95 transition-all"
                  >
                    {block.buttonText || 'Đăng Ký Thành Viên'}
                  </button>
                </div>
              )}

              {/* 5. STUDENT TESTIMONIALS */}
              {block.type === 'testimonial' && (
                <div className="space-y-10">
                  <div className="text-center">
                    <h2 
                      contentEditable={isLiveEditing}
                      suppressContentEditableWarning
                      onBlur={(e) => handleTextChange(block.id, 'title', e.currentTarget.innerText)}
                      className="text-3xl font-extrabold text-slate-900 dark:text-white outline-none"
                    >
                      {block.title}
                    </h2>
                    <p 
                      contentEditable={isLiveEditing}
                      suppressContentEditableWarning
                      onBlur={(e) => handleTextChange(block.id, 'subtitle', e.currentTarget.innerText)}
                      className="text-slate-500 mt-2 text-sm outline-none"
                    >
                      {block.subtitle}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                    {block.testimonials?.map((t, tIdx) => (
                      <div key={tIdx} className="bg-white dark:bg-slate-850 p-6 rounded-3xl border border-gray-150 dark:border-slate-800 shadow-sm flex flex-col justify-between relative group/item">
                        <div>
                          <div className="flex gap-1 text-amber-400 mb-4">
                            {[...Array(t.rating || 5)].map((_, i) => (
                              <Star key={i} size={15} fill="currentColor" />
                            ))}
                          </div>
                          <p 
                            contentEditable={isLiveEditing}
                            suppressContentEditableWarning
                            onBlur={(e) => handleTestimonialChange(block.id, block, tIdx, 'quote', e.currentTarget.innerText)}
                            className="text-slate-650 dark:text-slate-350 italic text-sm leading-relaxed mb-6 outline-none"
                          >
                            "{t.quote}"
                          </p>
                        </div>

                        <div className="flex items-center gap-4">
                          <img src={t.avatar} alt={t.name} className="w-12 h-12 rounded-full object-cover" />
                          <div>
                            <h4 
                              contentEditable={isLiveEditing}
                              suppressContentEditableWarning
                              onBlur={(e) => handleTestimonialChange(block.id, block, tIdx, 'name', e.currentTarget.innerText)}
                              className="font-bold text-slate-950 dark:text-white text-sm outline-none"
                            >
                              {t.name}
                            </h4>
                            <p 
                              contentEditable={isLiveEditing}
                              suppressContentEditableWarning
                              onBlur={(e) => handleTestimonialChange(block.id, block, tIdx, 'school', e.currentTarget.innerText)}
                              className="text-xs text-slate-400 outline-none"
                            >
                              {t.school}
                            </p>
                          </div>
                        </div>

                        {/* Fast image override in edit mode */}
                        {isLiveEditing && (
                          <div className="absolute bottom-1 right-2 bg-slate-800/80 px-2 py-0.5 rounded text-[8px] text-white opacity-0 group-hover/item:opacity-100 transition-opacity">
                            Avatar: <input type="text" value={t.avatar} onChange={(e) => handleTestimonialChange(block.id, block, tIdx, 'avatar', e.target.value)} className="bg-slate-900 border-0 text-[10px] py-0.5 px-1 rounded text-white" />
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* 6. AI INTERACTIVE CHATBOT ACCELERATOR */}
              {block.type === 'ai' && (
                <div className="max-w-3xl mx-auto bg-gradient-to-br from-indigo-900 to-slate-900 text-white rounded-3xl p-6 sm:p-8 shadow-2xl overflow-hidden relative">
                  <div className="absolute top-2 right-2 flex items-center gap-1.5 px-3 py-1 bg-white/10 backdrop-blur-md rounded-full text-[10px] font-black border border-white/15">
                    <Sparkles size={11} className="text-amber-300 animate-pulse" />
                    <span>Live AI Tutor</span>
                  </div>

                  <h3 
                    contentEditable={isLiveEditing}
                    suppressContentEditableWarning
                    onBlur={(e) => handleTextChange(block.id, 'title', e.currentTarget.innerText)}
                    className="text-xl sm:text-2xl font-black leading-tight mb-2 outline-none"
                  >
                    {block.title}
                  </h3>
                  <p 
                    contentEditable={isLiveEditing}
                    suppressContentEditableWarning
                    onBlur={(e) => handleTextChange(block.id, 'subtitle', e.currentTarget.innerText)}
                    className="text-slate-300 text-xs sm:text-sm mb-6 outline-none"
                  >
                    {block.subtitle}
                  </p>

                  <div className="space-y-4">
                    {/* Simulated screen conversation logs */}
                    <div className="bg-slate-950/60 rounded-2xl p-4 sm:p-5 min-h-[150px] max-h-[260px] overflow-y-auto font-sans text-sm sm:text-base leading-relaxed text-left text-slate-100 border border-white/5">
                      {aiResponse ? (
                        <div className="prose prose-sm prose-invert max-w-none">
                          <ReactMarkdown remarkPlugins={[remarkGfm, remarkBreaks]} rehypePlugins={[rehypeRaw]}>
                            {aiResponse}
                          </ReactMarkdown>
                        </div>
                      ) : (
                        <span className="text-slate-400 text-xs sm:text-sm font-sans block py-2">✍️ Em có thể gõ câu hỏi lập trình của mình ở ô bên dưới (Ví dụ: "Hàm print() dùng để làm gì?", "Làm sao để tạo một danh sách?",...) để được Trợ lý AI tuyệt đỉnh đồng hành, giải thích cặn kẽ nhé!</span>
                      )}
                    </div>

                    <div className="flex gap-2">
                      <input 
                        type="text" 
                        placeholder="Em muốn học hàm append..."
                        value={aiPrompt}
                        onChange={e => setAiPrompt(e.target.value)}
                        onKeyDown={e => {if(e.key === 'Enter') runAISample(aiPrompt);}}
                        className="flex-1 bg-slate-950/80 outline-none border border-white/10 rounded-xl px-4 py-3 text-sm sm:text-base text-white focus:ring-1 focus:ring-indigo-400"
                      />
                      <button 
                        onClick={() => runAISample(aiPrompt)}
                        disabled={aiLoading}
                        className="px-5 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 font-bold rounded-xl text-xs sm:text-sm flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
                        style={{ minHeight: '44px' }}
                      >
                        {aiLoading ? 'Đang trả lời...' : 'Hỏi AI'}
                      </button>
                    </div>
                  </div>
                </div>
              )}

              {/* 7. QUIZ CHALLENGE UNIT */}
              {block.type === 'quiz' && (
                <div className="max-w-2xl mx-auto bg-white dark:bg-slate-850 border border-slate-250 dark:border-slate-800 p-6 sm:p-8 rounded-[28px] shadow-sm">
                  <div className="flex items-center gap-2 text-rose-500 border border-rose-200/50 bg-rose-50 dark:bg-rose-950/20 px-3 py-1 rounded-full text-[10px] font-bold w-fit mb-4">
                    <HelpCircle size={12} />
                    <span>Hộp Trắc Nghiệm Bài Học</span>
                  </div>

                  <h3 className="text-xl font-bold mb-6 text-slate-900 dark:text-white">Kiểm tra ngay kiến thức chuẩn</h3>
                  
                  {/* Render questions list */}
                  <div className="space-y-4 text-left">
                    {(block.quizQuestions || [
                      { prompt: 'Lệnh gán nào sau đây là hợp lệ trong Python?', options: ['x = 10', '10 = x', 'x == 10'], answer: 0 }
                    ]).map((q, qIndex) => {
                      const selectedAns = quizAnswers[block.id]?.[qIndex];
                      const correctAns = q.answer;
                      return (
                        <div key={qIndex} className="p-4 bg-slate-50 dark:bg-slate-900 rounded-2xl border border-gray-100 dark:border-slate-800 space-y-3">
                          <p className="text-xs font-bold text-slate-800 dark:text-slate-200">{qIndex + 1}. {q.prompt}</p>
                          <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                            {q.options.map((opt, optIndex) => {
                              const isSelected = selectedAns === optIndex;
                              const isCorrect = optIndex === correctAns;
                              let buttonStyle = 'bg-white dark:bg-slate-800 hover:bg-slate-100 text-slate-700 dark:text-slate-300';
                              if (selectedAns !== undefined) {
                                if (isCorrect) buttonStyle = 'bg-green-500 text-white font-bold';
                                else if (isSelected) buttonStyle = 'bg-red-500 text-white';
                              }
                              return (
                                <button
                                  key={optIndex}
                                  onClick={() => {
                                    audioService.playClick();
                                    const isCorrect = optIndex === correctAns;
                                    if (isCorrect) audioService.playSuccess();
                                    else audioService.playError();
                                    setQuizAnswers(prev => ({
                                      ...prev,
                                      [block.id]: { ...(prev[block.id] || {}), [qIndex]: optIndex }
                                    }));
                                  }}
                                  className={`p-3 text-[11px] rounded-xl text-left border transition-all ${buttonStyle}`}
                                >
                                  {opt}
                                </button>
                              );
                            })}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 8. MINI LEARNING GAME (Interactive Code blocks fill in blank) */}
              {block.type === 'game' && (
                <div className="max-w-2xl mx-auto border border-amber-200/60 bg-amber-50/20 dark:bg-amber-950/10 p-6 sm:p-8 rounded-[32px] text-center space-y-4">
                  <h3 className="text-lg font-black text-amber-700 dark:text-amber-400 uppercase tracking-widest">{block.title || 'Thử Thách Khởi Động'}</h3>
                  <p className="text-xs text-slate-500">{block.subtitle}</p>

                  <div className="bg-slate-950 text-slate-200 font-mono text-left p-4 rounded-2xl text-xs overflow-hidden relative border border-slate-850">
                    <div className="absolute top-1.5 right-2 text-[9px] text-slate-600">INPUT AREA</div>
                    <pre className="whitespace-pre-wrap">{block.gameText || 'name = "_____"\nprint("Xin chào " + name)'}</pre>
                  </div>

                  <div className="flex flex-col sm:flex-row gap-2 justify-center pt-2">
                    <input 
                      type="text" 
                      placeholder="Gõ đáp án... (Ví dụ: Pilearn)"
                      value={gameInputs[block.id] || ''}
                      onChange={(e) => setGameInputs({ ...gameInputs, [block.id]: e.target.value })}
                      className="px-4 py-2.5 bg-white border border-gray-300 rounded-xl text-xs font-mono"
                    />
                    <button 
                      onClick={() => {
                        audioService.playClick();
                        const answerCorrect = (gameInputs[block.id] || '').trim() === (block.gameExpectedAnswer || 'Pilearn');
                        if (answerCorrect) audioService.playSuccess();
                        else audioService.playError();
                        setGameSuccess({ ...gameSuccess, [block.id]: answerCorrect });
                      }}
                      className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-1 cursor-pointer"
                    >
                      <Play size={12} fill="currentColor" />
                      <span>Chạy thử</span>
                    </button>
                  </div>

                  {gameSuccess[block.id] !== undefined && (
                    <div className={`p-3 rounded-xl text-xs font-bold leading-relaxed transition ${gameSuccess[block.id] ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'}`}>
                      {gameSuccess[block.id] 
                        ? '🎉 Nhúng chương trình thành công! Trả lời chính xác. Bạn đạt +50 XP.' 
                        : `❌ Sai rồi! Hoặc chưa chính xác chữ in hoa/thường. Gợi ý: ${block.gameHint || 'Nhập từ Pilearn'}`}
                    </div>
                  )}
                </div>
              )}

              {/* 9. FAQ ACCORDION BLOCK */}
              {block.type === 'faq' && (
                <div className="max-w-3xl mx-auto space-y-6 text-left">
                  <div className="text-center">
                    <h2 
                      contentEditable={isLiveEditing}
                      suppressContentEditableWarning
                      onBlur={(e) => handleTextChange(block.id, 'title', e.currentTarget.innerText)}
                      className="text-3xl font-extrabold text-slate-900 dark:text-white outline-none"
                    >
                      {block.title || 'FAQ'}
                    </h2>
                  </div>

                  <div className="space-y-3">
                    {block.faqItems?.map((faq, fIdx) => {
                      const isOpen = faqOpen[`${block.id}-${fIdx}`];
                      return (
                        <div key={fIdx} className="bg-white dark:bg-slate-850 border border-slate-205 dark:border-slate-800 rounded-2xl overflow-hidden shadow-xs transition-colors">
                          <button 
                            onClick={() => {
                              audioService.playClick();
                              setFaqOpen({ ...faqOpen, [`${block.id}-${fIdx}`]: !isOpen });
                            }}
                            className="w-full p-4 flex items-center justify-between font-bold text-slate-800 dark:text-white text-xs sm:text-sm text-left gap-4"
                          >
                            <span 
                              contentEditable={isLiveEditing}
                              suppressContentEditableWarning
                              onBlur={(e) => handleFAQChange(block.id, block, fIdx, 'question', e.currentTarget.innerText)}
                              className="outline-none"
                            >
                              {faq.question}
                            </span>
                            <ChevronDown size={16} className={`text-slate-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} />
                          </button>
                          
                          <AnimatePresence>
                            {isOpen && (
                              <motion.div 
                                initial={{ height: 0, opacity: 0 }}
                                animate={{ height: 'auto', opacity: 1 }}
                                exit={{ height: 0, opacity: 0 }}
                                className="border-t border-gray-100 dark:border-slate-800 px-4 py-3 text-xs leading-relaxed text-slate-600 dark:text-slate-400"
                              >
                                <p 
                                  contentEditable={isLiveEditing}
                                  suppressContentEditableWarning
                                  onBlur={(e) => handleFAQChange(block.id, block, fIdx, 'answer', e.currentTarget.innerText)}
                                  className="outline-none"
                                >
                                  {faq.answer}
                                </p>
                              </motion.div>
                            )}
                          </AnimatePresence>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* 10. PRICING TIERS BLOCK */}
              {block.type === 'pricing' && (
                <div className="space-y-10">
                  <div className="text-center">
                    <h2 
                      contentEditable={isLiveEditing}
                      suppressContentEditableWarning
                      onBlur={(e) => handleTextChange(block.id, 'title', e.currentTarget.innerText)}
                      className="text-3xl font-extrabold text-slate-900 dark:text-white outline-none"
                    >
                      {block.title || 'Gói Dịch Vụ'}
                    </h2>
                    <p 
                      contentEditable={isLiveEditing}
                      suppressContentEditableWarning
                      onBlur={(e) => handleTextChange(block.id, 'subtitle', e.currentTarget.innerText)}
                      className="text-slate-500 mt-2 text-sm outline-none"
                    >
                      {block.subtitle}
                    </p>
                  </div>

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-4xl mx-auto items-stretch">
                    {block.pricingTiers?.map((tier, pIdx) => (
                      <div 
                        key={pIdx} 
                        className={`p-8 rounded-[32px] border flex flex-col justify-between transition relative ${
                          tier.highlight 
                            ? 'bg-blue-600 text-white border-blue-500 shadow-xl scale-105 z-10' 
                            : 'bg-white border-gray-200 dark:bg-slate-850 dark:border-slate-800 shadow-sm'
                        }`}
                      >
                        {tier.highlight && (
                          <span className="absolute -top-3.5 left-1/2 -translate-x-1/2 bg-amber-500 text-white text-[9px] font-black tracking-widest uppercase px-3 py-1 rounded-full shadow-md">
                            Khuyên Dùng
                          </span>
                        )}

                        <div className="space-y-4">
                          <h3 
                            contentEditable={isLiveEditing}
                            suppressContentEditableWarning
                            onBlur={(e) => handlePricingChange(block.id, block, pIdx, 'name', e.currentTarget.innerText)}
                            className="font-black text-lg outline-none"
                          >
                            {tier.name}
                          </h3>
                          <div className="flex items-baseline gap-1">
                            <span 
                              contentEditable={isLiveEditing}
                              suppressContentEditableWarning
                              onBlur={(e) => handlePricingChange(block.id, block, pIdx, 'price', e.currentTarget.innerText)}
                              className="text-3xl font-black outline-none"
                            >
                              {tier.price}
                            </span>
                            <span 
                              contentEditable={isLiveEditing}
                              suppressContentEditableWarning
                              onBlur={(e) => handlePricingChange(block.id, block, pIdx, 'period', e.currentTarget.innerText)}
                              className="text-[10px] font-medium opacity-80 outline-none"
                            >
                              /{tier.period}
                            </span>
                          </div>

                          <div className="h-px bg-current opacity-20 my-4" />

                          <ul className="space-y-3.5 text-xs text-left">
                            {tier.features.map((feat, fId) => (
                              <li key={fId} className="flex items-center gap-2">
                                <CheckCircle2 size={14} className={tier.highlight ? 'text-amber-300' : 'text-blue-500'} />
                                <span>{feat}</span>
                              </li>
                            ))}
                          </ul>
                        </div>

                        <button 
                          onClick={handleRegisterClick}
                          className={`w-full py-3.5 rounded-full font-bold text-xs sm:text-sm mt-8 transition-all ${
                            tier.highlight 
                              ? 'bg-white text-blue-600 hover:bg-slate-100 shadow-md' 
                              : 'bg-slate-900 text-white hover:bg-slate-800'
                          }`}
                        >
                          Đăng ký ngay
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </div>

            {/* Quick in-between Block Insert Handle for premium WordPress style */}
            {isLiveEditing && onAddBlockClick && (
              <div className="w-full flex justify-center py-2 relative z-40 opacity-0 hover:opacity-100 transition-opacity">
                <button 
                  onClick={() => onAddBlockClick(idx + 1)}
                  className="bg-blue-600 hover:bg-blue-700 text-white text-[10px] font-black rounded-full px-4 py-1.5 flex items-center gap-1 shadow-md hover:scale-105 active:scale-95 cursor-pointer"
                >
                  <span>+ Chèn Khối tại đây</span>
                </button>
              </div>
            )}
          </div>
        );
      })}
    </div>
  );
}
