import React, { useEffect, useState } from 'react';
import { useAppContext } from '../store';
import { UserCircle, LogOut, Swords, Settings, Clock, Menu, X } from 'lucide-react';
import { useSettings } from '../contexts/SettingsContext';
import { getLocalNoCodeConfig, NoCodeConfig } from '../lib/nocode_store';
import { audioService } from '../utils/audio';

export function Navigation() {
  const { view, setView, role, authUser, profile, login, logout, progress, isDataLoaded } = useAppContext();
  const { setIsSettingsOpen } = useSettings();
  const [noCodeLayout, setNoCodeLayout] = useState<NoCodeConfig>(() => getLocalNoCodeConfig());
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [timeStr, setTimeStr] = useState('');

  useEffect(() => {
    setNoCodeLayout(getLocalNoCodeConfig());
    const handleStorage = () => setNoCodeLayout(getLocalNoCodeConfig());
    window.addEventListener('storage', handleStorage);
    window.addEventListener('pilearn_config_sync', handleStorage);
    return () => {
      window.removeEventListener('storage', handleStorage);
      window.removeEventListener('pilearn_config_sync', handleStorage);
    };
  }, []);

  useEffect(() => {
    const updateClock = () => {
      const formatter = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Ho_Chi_Minh',
        hour: '2-digit',
        minute: '2-digit',
      });
      setTimeStr(formatter.format(new Date()));
    };
    updateClock();
    const intervalId = setInterval(updateClock, 1000);
    return () => clearInterval(intervalId);
  }, []);

  const handleCTA = () => {
    if (!authUser) {
      login();
    } else {
      if (role === 'admin' || role === 'super_admin') setView('admin-dashboard');
      else if (role === 'teacher') setView('teacher-dashboard');
      else if (role === 'game_developer') setView('game-developer-dashboard');
      else setView('student-dashboard');
    }
  };

  return (
    <>
      <nav className="relative z-50 w-full pt-4 sticky top-0 px-3 sm:px-6 mb-6">
        <div className="mx-auto flex items-center justify-between p-[5px] transition-all duration-300 max-w-[1440px] bg-white rounded-full shadow-sm">
          {/* Logo */}
          <div className="flex items-center">
            <div 
              className="w-9 h-9 sm:w-10 sm:h-10 bg-gray-900 rounded-full flex items-center justify-center cursor-pointer shrink-0"
              onClick={() => {
                audioService.playClick();
                setView('home');
              }}
            >
              <span className="text-white text-[11px] sm:text-[12px] font-black tracking-tight">PY</span>
            </div>
            
            {/* Links Desktop */}
            <div className="hidden md:flex items-center gap-6 ml-6">
              {noCodeLayout?.menus && noCodeLayout.menus.length > 0 ? (
                noCodeLayout.menus
                  .slice()
                  .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
                  .map((m, mIdx) => (
                    <button
                      key={mIdx}
                      onClick={() => {
                        audioService.playClick();
                        if (m.url) window.open(m.url, '_blank');
                        else setView(m.viewAlias as any);
                      }}
                      className={`text-[14px] font-medium transition-colors duration-300 ${view === m.viewAlias ? 'text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}
                    >
                      {m.viewAlias === 'boss-battle' && <Swords className="w-[14px] h-[14px] inline shrink-0 mr-1 align-middle" />}
                      <span className="align-middle">{m.label}</span>
                    </button>
                  ))
              ) : (
                <>
                  <button onClick={() => { audioService.playClick(); setView('student-dashboard'); }} className={`text-[14px] font-medium transition-colors duration-300 ${view === 'student-dashboard' ? 'text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}>Bài học</button>
                  <button onClick={() => { audioService.playClick(); setView('roadmap'); }} className={`text-[14px] font-medium transition-colors duration-300 ${view === 'roadmap' ? 'text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}>Lộ trình</button>
                  <button onClick={() => { audioService.playClick(); setView('practice'); }} className={`text-[14px] font-medium transition-colors duration-300 ${view === 'practice' ? 'text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}>Thực hành</button>
                  <button onClick={() => { audioService.playClick(); setView('exams'); }} className={`text-[14px] font-medium transition-colors duration-300 ${view === 'exams' ? 'text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}>Kiểm tra</button>
                  <button onClick={() => { audioService.playClick(); setView('boss-battle'); }} className={`flex items-center gap-1 text-[14px] font-medium transition-colors duration-300 ${view === 'boss-battle' ? 'text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}>
                    <Swords className="w-[14px] h-[14px] shrink-0" />
                    Đánh Boss
                  </button>
                </>
              )}
            </div>
          </div>
          
          {/* Auth / Profile Desktop */}
          <div className="hidden md:flex items-center gap-4 pr-1">
            {/* Clock Desktop */}
            <div className="hidden lg:flex items-center gap-1.5 text-gray-600">
              <Clock className="w-[14px] h-[14px]" />
              <span className="text-[13px] font-medium">{timeStr} in Vietnam</span>
            </div>
            
            <div className="hidden lg:block h-4 w-px bg-gray-200"></div>

            {isDataLoaded ? (
              !authUser ? (
                <button 
                  onClick={() => {
                    audioService.playClick();
                    login();
                  }} 
                  className="bg-gray-900 text-white text-[13px] font-medium rounded-full px-5 py-2 hover:bg-gray-800 transition-colors"
                >
                  Đăng nhập
                </button>
              ) : (
                <div className="flex items-center gap-3 pr-2">
                  <button 
                    onClick={() => {
                      audioService.playClick();
                      handleCTA();
                    }}
                    className={`text-[14px] font-medium transition-colors duration-300 ${['admin-dashboard', 'teacher-dashboard', 'student-dashboard', 'game-developer-dashboard'].includes(view) ? 'text-gray-900' : 'text-gray-500 hover:text-gray-900'}`}
                  >
                    Dashboard
                  </button>
                  
                  <div className="h-4 w-px bg-gray-200 mx-1"></div>
                  
                  {role === 'student' && (
                    <div className="flex items-center gap-3">
                       <div className="flex items-center gap-1">
                         <span className={`text-[12px] ${(progress?.streak || 0) > 0 ? 'animate-bounce inline-block' : 'grayscale opacity-50'}`}>🔥</span>
                         <span className="text-[12px] font-bold text-gray-900">{progress?.streak || 0}</span>
                       </div>
                       <div className="flex flex-col items-center justify-center shrink-0 w-12">
                          <div className="text-[10px] font-bold text-[#F26522] leading-none mb-0.5">LV {Math.floor((progress?.xp || 0) / 100) + 1}</div>
                          <div className="w-full h-1 bg-gray-100 rounded-full overflow-hidden">
                             <div className="h-full bg-[#F26522]" style={{ width: `${(progress?.xp || 0) % 100}%` }}></div>
                          </div>
                       </div>
                    </div>
                  )}

                  <span className="text-[13px] font-medium flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-gray-50 text-gray-900 border border-gray-100">
                    <UserCircle className="w-4 h-4 text-gray-400" />
                    <span className="max-w-[80px] truncate">{profile?.displayName || 'User'}</span>
                  </span>

                  <button onClick={() => { audioService.playClick(); setIsSettingsOpen(true); }} className="text-gray-400 hover:text-gray-900 transition-colors">
                    <Settings className="w-4 h-4" />
                  </button>
                  <button onClick={() => { audioService.playClick(); logout(); }} className="text-gray-400 hover:text-[#F26522] transition-colors">
                    <LogOut className="w-4 h-4" />
                  </button>
                </div>
              )
            ) : (
              <div className="h-8 w-20 animate-pulse rounded-full bg-gray-100 mr-2"></div>
            )}
          </div>

          {/* Mobile Menu Toggle */}
          <div className="md:hidden pr-1">
            <button 
              onClick={() => setIsMenuOpen(true)}
              className="w-9 h-9 bg-gray-900 rounded-full flex items-center justify-center text-white"
            >
              <Menu className="w-4 h-4" />
            </button>
          </div>
        </div>
      </nav>

      {/* Mobile Menu Overlay */}
      {isMenuOpen && (
        <div className="fixed inset-0 z-[100] flex flex-col justify-end">
          <div 
            className="absolute inset-0 bg-black/60 transition-opacity" 
            onClick={() => setIsMenuOpen(false)}
          />
          <div className="relative bg-white rounded-2xl mx-3 mb-3 p-6 pb-8 transition-transform duration-500 ease-[cubic-bezier(0.32,0.72,0,1)] animate-in slide-in-from-bottom-[100%]">
            <div className="flex justify-between items-center mb-10">
              <div className="flex items-center gap-2">
                <Clock className="w-4 h-4 text-gray-600" />
                <span className="text-[13px] text-gray-600 font-medium">{timeStr} in Vietnam</span>
              </div>
              <button 
                onClick={() => setIsMenuOpen(false)}
                className="w-9 h-9 bg-gray-100 rounded-full flex items-center justify-center text-gray-900"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
            
            <div className="flex flex-col gap-6 mb-8 overflow-y-auto max-h-[50vh]">
              {noCodeLayout?.menus && noCodeLayout.menus.length > 0 ? (
                noCodeLayout.menus
                  .slice()
                  .sort((a, b) => (a.order ?? 0) - (b.order ?? 0))
                  .map((m, mIdx) => (
                    <button
                      key={mIdx}
                      onClick={() => {
                        audioService.playClick();
                        setIsMenuOpen(false);
                        if (m.url) window.open(m.url, '_blank');
                        else setView(m.viewAlias as any);
                      }}
                      className="text-[28px] sm:text-[32px] font-medium text-left text-gray-900 tracking-tight flex items-center gap-2"
                    >
                      {m.viewAlias === 'boss-battle' && <Swords className="w-6 h-6 shrink-0 text-gray-400" />}
                      {m.label}
                    </button>
                  ))
              ) : (
                <>
                  <button onClick={() => { audioService.playClick(); setIsMenuOpen(false); setView('student-dashboard'); }} className="text-[28px] sm:text-[32px] font-medium text-left text-gray-900 tracking-tight">Bài học</button>
                  <button onClick={() => { audioService.playClick(); setIsMenuOpen(false); setView('roadmap'); }} className="text-[28px] sm:text-[32px] font-medium text-left text-gray-900 tracking-tight">Lộ trình</button>
                  <button onClick={() => { audioService.playClick(); setIsMenuOpen(false); setView('practice'); }} className="text-[28px] sm:text-[32px] font-medium text-left text-gray-900 tracking-tight">Thực hành</button>
                  <button onClick={() => { audioService.playClick(); setIsMenuOpen(false); setView('exams'); }} className="text-[28px] sm:text-[32px] font-medium text-left text-gray-900 tracking-tight">Kiểm tra</button>
                  <button onClick={() => { audioService.playClick(); setIsMenuOpen(false); setView('boss-battle'); }} className="text-[28px] sm:text-[32px] font-medium text-left text-gray-900 tracking-tight flex items-center gap-2">
                    <Swords className="w-6 h-6 shrink-0 text-gray-400" />
                    Đánh Boss
                  </button>
                </>
              )}

              <div className="h-px bg-gray-100 my-2"></div>
              
              <button onClick={() => { audioService.playClick(); setIsMenuOpen(false); handleCTA(); }} className="text-[20px] font-medium text-left text-gray-500">Dashboard</button>
              <button onClick={() => { audioService.playClick(); setIsMenuOpen(false); setIsSettingsOpen(true); }} className="text-[20px] font-medium text-left text-gray-500 flex items-center gap-2"><Settings className="w-5 h-5"/> Cài đặt</button>
              {authUser ? (
                <button onClick={() => { audioService.playClick(); setIsMenuOpen(false); logout(); }} className="text-[20px] font-medium text-left text-gray-500 flex items-center gap-2"><LogOut className="w-5 h-5"/> Đăng xuất</button>
              ) : (
                <button onClick={() => { audioService.playClick(); setIsMenuOpen(false); login(); }} className="text-[20px] font-medium text-left text-gray-500">Đăng nhập</button>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  );
}
