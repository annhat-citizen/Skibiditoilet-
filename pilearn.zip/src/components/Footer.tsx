import React, { useState, useEffect } from "react";
import {
  Github,
  Facebook,
  Twitter,
  Youtube,
  Code2,
  Instagram,
  Music,
  Globe,
  Mail,
  Phone,
} from "lucide-react";
import { useAppContext } from "../store";
import {
  getLocalNoCodeConfig,
  NoCodeSystemSettings,
} from "../lib/nocode_store";

export function Footer() {
  const [showToast, setShowToast] = useState(false);
  const { setView } = useAppContext();
  const [sysSettings, setSysSettings] = useState<NoCodeSystemSettings | null>(
    null,
  );

  useEffect(() => {
    const cfg = getLocalNoCodeConfig();
    setSysSettings(cfg.systemSettings);

    // Listen to localStorage modifications
    const handleStorage = () => {
      setSysSettings(getLocalNoCodeConfig().systemSettings);
    };
    window.addEventListener("storage", handleStorage);
    window.addEventListener("pilearn_config_sync", handleStorage);

    return () => {
      window.removeEventListener("storage", handleStorage);
      window.removeEventListener("pilearn_config_sync", handleStorage);
    };
  }, []);

  const handleLinkClick = (viewAlias?: string, url?: string) => {
    if (viewAlias) {
      setView(viewAlias as any);
      return;
    }
    if (url) {
      window.open(url, "_blank");
      return;
    }
    setShowToast(true);
    setTimeout(() => {
      setShowToast(false);
    }, 3000);
  };

  return (
    <footer className="relative bg-[#F5F5F5] dark:bg-gray-900 border-t border-gray-200 dark:border-gray-800 mt-20 pt-16 pb-10 text-gray-900 dark:text-gray-200 overflow-hidden">
      {/* Toast Notification */}
      {showToast && (
        <div className="fixed bottom-4 right-4 bg-gray-900 text-white px-4 py-2 rounded-lg shadow-lg z-50 text-sm font-medium animate-in fade-in slide-in-from-bottom-4">
          Tính năng đang được phát triển. Vui lòng quay lại sau!
        </div>
      )}

      <div className="relative z-10 max-w-[1440px] mx-auto px-6 sm:px-8">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
          {/* Logo Brand */}
          <div className="col-span-1 md:col-span-1">
            <div className="flex items-center gap-2 mb-4">
              {sysSettings?.headerLogoImage ? (
                <img
                  src={sysSettings.headerLogoImage}
                  alt="Brand"
                  className="h-10 w-10 shrink-0 object-cover rounded-full border border-gray-100 dark:border-gray-700 shadow-sm"
                />
              ) : (
                <div className="w-10 h-10 bg-gray-900 rounded-full flex items-center justify-center shrink-0">
                  <span className="text-white text-[11px] font-bold tracking-tight">AX</span>
                </div>
              )}
              <span className="font-extrabold tracking-tight text-2xl text-gray-900 dark:text-white ml-2">
                {sysSettings?.headerLogoText ? (
                  sysSettings.headerLogoText
                ) : (
                  <>Axion Studio</>
                )}
              </span>
            </div>
            <p className="text-slate-500 text-sm mb-6 max-w-xs leading-relaxed">
              {sysSettings?.aboutText ||
                "Nền tảng học lập trình thân thiện, vui nhộn và vô cùng hiệu quả dành cho mọi lứa tuổi."}
            </p>
            <div className="flex flex-wrap gap-2 text-slate-400">
              {sysSettings?.socialLinks &&
              sysSettings.socialLinks.length > 0 ? (
                sysSettings.socialLinks.map((link) => {
                  let Icon = Globe;
                  let hoverClass = "hover:bg-amber-500 hover:text-white";
                  if (link.platform === "facebook") {
                    Icon = Facebook;
                    hoverClass = "hover:bg-blue-600 hover:text-white";
                  } else if (link.platform === "twitter") {
                    Icon = Twitter;
                    hoverClass = "hover:bg-sky-500 hover:text-white";
                  } else if (link.platform === "youtube") {
                    Icon = Youtube;
                    hoverClass = "hover:bg-red-600 hover:text-white";
                  } else if (link.platform === "github") {
                    Icon = Github;
                    hoverClass = "hover:bg-black hover:text-white";
                  } else if (link.platform === "instagram") {
                    Icon = Instagram;
                    hoverClass =
                      "hover:bg-gradient-to-r hover:from-purple-500 hover:to-pink-500 hover:text-white";
                  } else if (link.platform === "tiktok") {
                    Icon = Music;
                    hoverClass = "hover:bg-slate-950 hover:text-white";
                  }

                  const isCustom = link.platform === "custom";
                  return (
                    <button
                      key={link.id}
                      type="button"
                      onClick={() => handleLinkClick(undefined, link.url)}
                      className={`h-9 flex items-center justify-center transition-all duration-300 ${
                        isCustom
                          ? "px-3 text-xs font-bold rounded-lg bg-slate-200 dark:bg-slate-800 text-slate-700 dark:text-slate-300 hover:bg-amber-500 hover:text-white"
                          : `w-9 rounded-full bg-slate-200 dark:bg-slate-800 ${hoverClass}`
                      }`}
                      title={link.label || link.platform}
                    >
                      {isCustom ? (
                        <span className="text-[11px] font-bold tracking-tight">
                          {link.label || "Liên kết"}
                        </span>
                      ) : (
                        <Icon className="w-4 h-4" />
                      )}
                    </button>
                  );
                })
              ) : (
                <>
                  <button
                    type="button"
                    onClick={() =>
                      handleLinkClick(undefined, "https://facebook.com")
                    }
                    className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center hover:bg-blue-600 hover:text-white transition-all duration-300"
                  >
                    <Facebook className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleLinkClick(undefined, "https://twitter.com")
                    }
                    className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center hover:bg-sky-500 hover:text-white transition-all duration-300"
                  >
                    <Twitter className="w-4 h-4" />
                  </button>
                  <button
                    type="button"
                    onClick={() =>
                      handleLinkClick(undefined, "https://youtube.com")
                    }
                    className="w-9 h-9 rounded-full bg-slate-200 dark:bg-slate-800 flex items-center justify-center hover:bg-red-600 hover:text-white transition-all duration-300"
                  >
                    <Youtube className="w-4 h-4" />
                  </button>
                </>
              )}
            </div>
          </div>

          {/* Dynamic Columns */}
          {sysSettings?.footerColumns?.slice(0, 3).map((col) => (
            <div key={col.id}>
              <h3 className="text-xl font-bold mb-6">{col.title}</h3>
              <ul className="space-y-4 text-sm text-slate-500 dark:text-slate-400 font-medium">
                {col.links.map((link, idx) => (
                  <li key={idx}>
                    <button
                      onClick={() => handleLinkClick(link.viewAlias, link.url)}
                      className="hover:text-blue-500 transition text-left"
                    >
                      {link.label}
                    </button>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>

        <div className="border-t border-slate-200 dark:border-slate-800 pt-8 mt-8 flex flex-col md:flex-row justify-between items-center gap-4 text-sm text-slate-500">
          <div className="flex items-center gap-2 mb-2 md:mb-0">
            <span>
              {sysSettings?.footerText ||
                "© 2026 Pilearn. Bản quyền thuộc về Đội ngũ GDPT Tin học 10."}
            </span>
          </div>
          <div className="flex items-center gap-4 text-xs font-medium">
             <span className="flex items-center gap-1.5"><Mail className="w-4 h-4 text-indigo-400" /> hotro@pilearn.vn</span>
             <span className="flex items-center gap-1.5"><Phone className="w-4 h-4 text-indigo-400" /> 0987.654.321</span>
          </div>
          <div className="flex items-center text-xs opacity-70">
            <Code2 className="w-4 h-4 mr-2" />
            Kid-Friendly & AI Powered
          </div>
        </div>
      </div>
    </footer>
  );
}
