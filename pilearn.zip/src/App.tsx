/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect } from 'react';
import { AppProvider, useAppContext } from './store';
import { SettingsProvider } from './contexts/SettingsContext';
import { Navigation } from './components/Navigation';
import { Footer } from './components/Footer';
import { Home } from './views/Home';
import { Roadmap } from './views/Roadmap';
import { LessonView } from './views/LessonView';
import { Practice } from './views/Practice';
import { ExamCenter } from './views/ExamCenter';
import { StudentDashboard } from './views/StudentDashboard';
import { TeacherDashboard } from './views/TeacherDashboard';
import { AdminDashboard } from './views/AdminDashboard';
import { GameDeveloperDashboard } from './views/GameDeveloperDashboard';
import { AboutUs } from './views/AboutUs';
import { CompleteProfileModal } from './components/CompleteProfileModal';
import { SettingsModal } from './components/SettingsModal';
import { Story } from './views/Story';
import { Privacy } from './views/Privacy';
import { Terms } from './views/Terms';
import { HelpCenter } from './views/HelpCenter';
import { Shop } from './views/Shop';
import { BossBattle } from './views/BossBattle';
import { Docs } from './views/Docs';
import { Safety } from './views/Safety';
import { LevelUpPopup } from './components/LevelUpPopup';
import { StreakPopup } from './components/StreakPopup';
import { CommandPalette } from './components/CommandPalette';
import { motion, AnimatePresence } from 'motion/react';
import { Sun, Moon } from 'lucide-react';
import { Shader, ChromaFlow, FilmGrain, FlutedGlass, Swirl } from 'shaders/react';

function MainLayout() {
  const { view, updateStudyTime } = useAppContext();
  const [mousePos, setMousePos] = useState({ x: 50, y: 50 });
  const [isDarkMode, setIsDarkMode] = useState(() => {
    return localStorage.getItem('theme') === 'dark' || 
      (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches);
  });

  useEffect(() => {
    const interval = setInterval(() => {
      updateStudyTime(60);
    }, 60000);
    return () => clearInterval(interval);
  }, [updateStudyTime]);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
      localStorage.setItem('theme', 'dark');
    } else {
      document.documentElement.classList.remove('dark');
      localStorage.setItem('theme', 'light');
    }
  }, [isDarkMode]);

  useEffect(() => {
    const handleGlobalMouseMove = (e: MouseEvent) => {
      const x = (e.clientX / window.innerWidth) * 100;
      const y = (e.clientY / window.innerHeight) * 100;
      setMousePos({ x, y });
    };
    window.addEventListener('mousemove', handleGlobalMouseMove);
    return () => window.removeEventListener('mousemove', handleGlobalMouseMove);
  }, []);

  const toggleDarkMode = () => setIsDarkMode(prev => !prev);

  // Define layout colors based on theme and view
  const baseLayoutClass = 'bg-[#F5F5F5] dark:bg-gray-900 text-gray-900 dark:text-gray-100 selection:bg-[#F26522] selection:text-white';

  return (
    <div className={`min-h-[100vh] flex flex-col font-sans transition-colors duration-500 relative overflow-hidden ${baseLayoutClass}`}>
      {/* Dark Mode Toggle Button */}
      <button 
        onClick={toggleDarkMode}
        className="tutorial-step-4 fixed bottom-6 right-6 z-50 p-3 rounded-full bg-white/80 dark:bg-gray-800/80 backdrop-blur-md text-gray-800 dark:text-gray-200 border border-gray-200 dark:border-gray-700 shadow-lg hover:scale-110 transition-transform"
        aria-label="Toggle Dark Mode"
      >
        {isDarkMode ? <Sun size={20} /> : <Moon size={20} />}
      </button>

      {/* Interactive Global Background (only visible when not on home video) */}
      {view !== 'home' && (
        <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
          {['roadmap', 'lesson', 'practice', 'exams', 'student-dashboard'].includes(view) ? (
            <Shader className="w-full h-full">
              <Swirl 
                colorA={isDarkMode ? "#0b0f19" : "#ffffff"} 
                colorB={isDarkMode ? "#020617" : "#f5f5f5"} 
                detail={1.7} 
              />
              <ChromaFlow 
                baseColor={isDarkMode ? "#0b0f19" : "#ffffff"} 
                downColor="#F26522" 
                leftColor="#F26522" 
                rightColor="#F26522" 
                upColor="#F26522" 
                momentum={13} 
                radius={3.5} 
              />
              <FlutedGlass 
                aberration={isDarkMode ? 0.3 : 0.61} 
                angle={31} 
                frequency={8} 
                highlight={isDarkMode ? 0.05 : 0.12} 
                highlightSoftness={0} 
                lightAngle={-90} 
                refraction={4} 
                shape="rounded" 
                softness={1} 
                speed={0.15} 
              />
              <FilmGrain strength={0.05} />
            </Shader>
          ) : (
            <>
              {/* Soft base gradients */}
              <div className="absolute -top-[20%] -right-[10%] w-[50rem] h-[50rem] bg-pink-100/30 dark:bg-pink-900/10 rounded-full blur-[100px]" />
              <div className="absolute -bottom-[20%] -left-[10%] w-[60rem] h-[60rem] bg-blue-100/30 dark:bg-blue-900/10 rounded-full blur-[120px]" />
              
              {/* Active mouse follower glow */}
              <div 
                className="absolute w-[40rem] h-[40rem] bg-blue-300/10 dark:bg-blue-400/5 rounded-full blur-[80px] transition-transform duration-200 ease-out z-0" 
                style={{ transform: `translate(calc(${mousePos.x}vw - 20rem), calc(${mousePos.y}vh - 20rem))` }}
              />
              <div 
                className="absolute w-[30rem] h-[30rem] bg-indigo-300/10 dark:bg-indigo-400/5 rounded-full blur-[80px] transition-transform duration-500 ease-out z-0" 
                style={{ transform: `translate(calc(${mousePos.x}vw - 15rem), calc(${mousePos.y}vh - 15rem))` }}
              />
            </>
          )}
        </div>
      )}

      <div className="relative z-10 flex flex-col flex-1 min-h-screen">
        {view !== 'home' && <Navigation />}
        <main className={`flex-1 relative ${view !== 'home' ? 'pb-24' : ''} flex flex-col`}>
          <AnimatePresence mode="wait">
            <motion.div
              key={view}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              exit={{ opacity: 0, x: -20 }}
              transition={{ duration: 0.3, ease: 'easeOut' }}
              className="w-full h-full flex flex-col flex-1"
            >
              {view === 'home' && <Home />}
              {view === 'roadmap' && <Roadmap />}
              {view === 'lesson' && <LessonView />}
              {view === 'practice' && <Practice />}
              {view === 'exams' && <ExamCenter />}
              {view === 'student-dashboard' && <StudentDashboard />}
              {view === 'teacher-dashboard' && <TeacherDashboard />}
              {view === 'admin-dashboard' && <AdminDashboard />}
              {view === 'game-developer-dashboard' && <GameDeveloperDashboard />}
              {view === 'about' && <AboutUs />}
              {view === 'story' && <Story />}
              {view === 'privacy' && <Privacy />}
              {view === 'terms' && <Terms />}
              {view === 'help' && <HelpCenter />}
              {view === 'shop' && <Shop />}
              {view === 'boss-battle' && <BossBattle />}
              {view === 'docs' && <Docs />}
              {view === 'safety' && <Safety />}
            </motion.div>
          </AnimatePresence>
        </main>
        {view !== 'home' && (
          <div className="mt-20"></div>
        )}
        {view !== 'home' && <Footer />}
      </div>
      <CompleteProfileModal />
      <LevelUpPopup />
      <StreakPopup />
      <CommandPalette />
    </div>
  );
}

export default function App() {
  return (
    <SettingsProvider>
      <AppProvider>
        <MainLayout />
        <SettingsModal />
      </AppProvider>
    </SettingsProvider>
  );
}

