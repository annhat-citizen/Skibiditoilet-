import React from 'react';
import { Shader, ChromaFlow, FilmGrain, FlutedGlass, Swirl } from 'shaders/react';
import { ArrowRight, BookOpen, Code2, Trophy, Swords, Sparkles, Terminal, GraduationCap, CheckCircle2 } from 'lucide-react';
import { useAppContext } from '../store';
import { Navigation } from '../components/Navigation';

const StarburstIcon = () => (
  <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" className="w-5 h-5 sm:w-6 sm:h-6 fill-current text-[#F26522]">
    <path d="m19.6 66.5 19.7-11 .3-1-.3-.5h-1l-3.3-.2-11.2-.3L14 53l-9.5-.5-2.4-.5L0 49l.2-1.5 2-1.3 2.9.2 6.3.5 9.5.6 6.9.4L38 49.1h1.6l.2-.7-.5-.4-.4-.4L29 41l-10.6-7-5.6-4.1-3-2-1.5-2-.6-4.2 2.7-3 3.7.3.9.2 3.7 2.9 8 6.1L37 36l1.5 1.2.6-.4.1-.3-.7-1.1L33 25l-6-10.4-2.7-4.3-.7-2.6c-.3-1-.4-2-.4-3l3-4.2L28 0l4.2.6L33.8 2l2.6 6 4.1 9.3L47 29.9l2 3.8 1 3.4.3 1h.7v-.5l.5-7.2 1-8.7 1-11.2.3-3.2 1.6-3.8 3-2L61 2.6l2 2.9-.3 1.8-1.1 7.7L59 27.1l-1.5 8.2h.9l1-1.1 4.1-5.4 6.9-8.6 3-3.5L77 13l2.3-1.8h4.3l3.1 4.7-1.4 4.9-4.4 5.6-3.7 4.7-5.3 7.1-3.2 5.7.3.4h.7l12-2.6 6.4-1.1 7.6-1.3 3.5 1.6.4 1.6-1.4 3.4-8.2 2-9.6 2-14.3 3.3-.2.1.2.3 6.4.6 2.8.2h6.8l12.6 1 3.3 2 1.9 2.7-.3 2-5.1 2.6-6.8-1.6-16-3.8-5.4-1.3h-.8v.4l4.6 4.5 8.3 7.5L89 80.1l.5 2.4-1.3 2-1.4-.2-9.2-7-3.6-3-8-6.8h-.5v.7l1.8 2.7 9.8 14.7.5 4.5-.7 1.4-2.6 1-2.7-.6-5.8-8-6-9-4.7-8.2-.5.4-2.9 30.2-1.3 1.5-3 1.2-2.5-2-1.4-3 1.4-6.2 1.6-8 1.3-6.4 1.2-7.9.7-2.6v-.2H49L43 72l-9 12.3-7.2 7.6-1.7.7-3-1.5.3-2.8L24 86l10-12.8 6-7.9 4-4.6-.1-.5h-.3L17.2 77.4l-4.7.6-2-2 .2-3 1-1 8-5.5Z"/>
  </svg>
);

export function Home({ previewAlias }: { previewAlias?: string } = {}) {
  const { setView } = useAppContext();

  return (
    <div className="w-full bg-[#EFEFEF] dark:bg-slate-950 min-h-screen text-slate-900 dark:text-slate-100 font-sans selection:bg-[#F26522] selection:text-white transition-colors duration-300">
      {/* SECTION 1: HERO */}
      <section className="relative w-full h-screen min-h-[650px] flex flex-col justify-between overflow-hidden">
        {/* Background Shader */}
        <div className="absolute inset-0 z-10 pointer-events-none">
          <Shader className="w-full h-full">
            <Swirl colorA="#ffffff" colorB="#f3f4f6" detail={1.7} />
            <ChromaFlow baseColor="#ffffff" downColor="#f26522" leftColor="#f26522" rightColor="#f26522" upColor="#f26522" momentum={13} radius={3.5} />
            <FlutedGlass aberration={0.61} angle={31} frequency={8} highlight={0.12} highlightSoftness={0} lightAngle={-90} refraction={4} shape="rounded" softness={1} speed={0.15} />
            <FilmGrain strength={0.05} />
          </Shader>
        </div>

        {/* Navigation */}
        <Navigation />

        {/* Hero Content */}
        <div className="relative z-20 flex-1 flex flex-col justify-end w-full max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12 pb-14 sm:pb-16 lg:pb-20">
          <div className="text-[12px] sm:text-[13px] text-[#F26522] dark:text-[#F26522] font-black uppercase tracking-widest mb-4 flex items-center gap-2">
            <Sparkles className="w-4 h-4 animate-pulse" />
            <span>Nền tảng học lập trình Python THPT thế hệ mới</span>
          </div>
          <h1 className="font-black text-slate-900 dark:text-white tracking-tight leading-[1.05] text-[clamp(2.25rem,6.5vw,4.5rem)]">
            Học Lập Trình Python <br className="hidden sm:block" />
            Chuẩn THPT & Lớp 10.
          </h1>
          <p className="mt-5 text-slate-600 dark:text-slate-300 max-w-2xl text-sm sm:text-base md:text-lg leading-relaxed font-medium">
            Học lý thuyết tương tác trực quan, viết code và chạy trực tiếp trên trình duyệt, thử thách thực hành đa dạng và rèn luyện tư duy lập trình qua các trận đấu Boss hấp dẫn.
          </p>
          <div className="mt-8 sm:mt-10 flex flex-col sm:flex-row items-start sm:items-center gap-4 sm:gap-5">
            <button 
              onClick={() => setView('student-dashboard')}
              className="bg-[#F26522] hover:bg-[#e05a1a] transition-colors duration-300 text-white text-[13px] sm:text-[14px] font-extrabold rounded-full pl-5 sm:pl-6 pr-2 py-2 flex items-center gap-3 sm:gap-4 group shadow-lg shadow-[#F26522]/20"
            >
              <div className="h-[20px] overflow-hidden flex flex-col justify-start">
                <div className="transition-transform duration-500 ease-[cubic-bezier(0.25,0.1,0.25,1)] group-hover:-translate-y-full flex flex-col">
                  <span className="h-[20px] flex items-center">Bắt đầu học miễn phí</span>
                  <span className="h-[20px] flex items-center">Vào bài học ngay</span>
                </div>
              </div>
              <div className="w-7 h-7 sm:w-8 sm:h-8 bg-white rounded-full flex items-center justify-center text-[#F26522]">
                <ArrowRight className="w-4 h-4 transition-transform duration-500 ease-[cubic-bezier(0.25,0.1,0.25,1)] group-hover:-rotate-45" />
              </div>
            </button>
            
            <div className="bg-white/80 dark:bg-slate-900/80 backdrop-blur-md rounded-full border border-slate-200/50 dark:border-slate-850 px-4 py-2.5 flex items-center gap-3 shadow-md">
              <StarburstIcon />
              <span className="text-[12px] sm:text-[13px] font-bold text-slate-800 dark:text-slate-200">Chuẩn Chương Trình Mới</span>
              <span className="bg-[#F26522]/10 text-[#F26522] dark:bg-[#F26522]/20 text-[10px] sm:text-[11px] px-2 py-0.5 rounded-full font-extrabold border border-[#F26522]/30">Bộ GD&ĐT</span>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 2: KEY FEATURES */}
      <section className="w-full bg-white dark:bg-slate-950 pt-20 sm:pt-24 lg:pt-32 pb-16 sm:pb-20 lg:pb-28 overflow-hidden relative z-30 transition-colors duration-300">
        <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12">
          <div className="flex items-center gap-3 mb-6 sm:mb-8">
            <div className="w-7 h-7 rounded-full bg-[#F26522] text-white text-[12px] font-black flex items-center justify-center shadow-md">
              1
            </div>
            <div className="text-[12px] sm:text-[13px] font-extrabold border border-slate-200 dark:border-slate-800 rounded-full px-4 py-1.5 text-slate-600 dark:text-slate-300">
              Phương pháp học tối ưu
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-[45%_1fr] gap-12 lg:gap-16 items-start">
            <div>
              <h2 className="font-black text-slate-900 dark:text-white tracking-tight leading-[1.1] text-[clamp(1.75rem,4vw,3rem)] mb-6">
                Chinh phục lập trình Python theo cách trực quan nhất.
              </h2>
              <p className="text-slate-600 dark:text-slate-300 text-sm sm:text-base leading-relaxed mb-8 font-medium">
                Hệ thống giáo trình được thiết kế đặc thù cho học sinh THPT, kết hợp hoàn hảo giữa lý thuyết tinh gọn, ví dụ thực tế và các công cụ lập trình tương tác thông minh ngay trong trình duyệt.
              </p>
              
              <div className="space-y-4">
                <div className="flex gap-3 items-start">
                  <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">Không cần cài đặt phức tạp</h4>
                    <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">Chạy thử code Python và xem kết quả tức thì nhờ trình biên dịch tích hợp thông minh.</p>
                  </div>
                </div>
                <div className="flex gap-3 items-start">
                  <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">Học qua lỗi sai với AI Tutor</h4>
                    <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">Trợ lý học tập AI thông minh luôn sẵn sàng giải thích lỗi cú pháp và gợi ý sửa code.</p>
                  </div>
                </div>
                <div className="flex gap-3 items-start">
                  <CheckCircle2 className="w-5 h-5 text-green-500 shrink-0 mt-0.5" />
                  <div>
                    <h4 className="font-bold text-slate-900 dark:text-white text-sm sm:text-base">Gỡ lỗi tương tác vui nhộn</h4>
                    <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">Rèn luyện kỹ năng tìm lỗi sai và gỡ lỗi (Debugging) thông qua trò chơi Đánh Boss cực kỳ lôi cuốn.</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Feature Bento Grid (Liquid Glass Styling) */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
              <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 p-6 rounded-3xl shadow-md space-y-4 flex flex-col justify-between">
                <div className="p-3 bg-blue-500/10 text-blue-600 dark:text-blue-400 rounded-2xl w-fit">
                  <BookOpen className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white text-lg mb-1">Lý thuyết Trực quan</h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">Các khái niệm cơ bản về biến, kiểu dữ liệu, rẽ nhánh và lặp được diễn giải bằng sơ đồ trực quan sinh động.</p>
                </div>
              </div>

              <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 p-6 rounded-3xl shadow-md space-y-4 flex flex-col justify-between">
                <div className="p-3 bg-amber-500/10 text-amber-600 dark:text-amber-400 rounded-2xl w-fit">
                  <Code2 className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white text-lg mb-1">Interactive IDE</h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">Vừa đọc lý thuyết vừa chỉnh sửa và chạy thử code Python ngay tại chỗ, quan sát đầu ra tức thì.</p>
                </div>
              </div>

              <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 p-6 rounded-3xl shadow-md space-y-4 flex flex-col justify-between">
                <div className="p-3 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 rounded-2xl w-fit">
                  <Trophy className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white text-lg mb-1">Thực hành & Kiểm tra</h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">Thực hành các dự án thực tế có chấm điểm tự động và làm bài kiểm tra trắc nghiệm chuẩn cấu trúc.</p>
                </div>
              </div>

              <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 p-6 rounded-3xl shadow-md space-y-4 flex flex-col justify-between">
                <div className="p-3 bg-indigo-500/10 text-indigo-600 dark:text-indigo-400 rounded-2xl w-fit">
                  <Swords className="w-6 h-6" />
                </div>
                <div>
                  <h3 className="font-black text-slate-900 dark:text-white text-lg mb-1">Thách thức Đấu Boss</h3>
                  <p className="text-xs sm:text-sm text-slate-500 dark:text-slate-400">Gặp gỡ các Boss lỗi cú pháp, lỗi logic, áp dụng kiến thức lập trình để hạ gục Boss và tích luỹ điểm XP.</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* SECTION 3: COURSE UNITS */}
      <section className="w-full bg-[#F5F5F5] dark:bg-slate-900/50 pt-20 sm:pt-24 pb-20 sm:pb-24 relative z-30 transition-colors duration-300">
        <div className="max-w-[1440px] mx-auto px-5 sm:px-8 lg:px-12">
          <div className="flex items-center gap-3 mb-6 sm:mb-8">
            <div className="w-7 h-7 rounded-full bg-[#F26522] text-white text-[12px] font-black flex items-center justify-center shadow-md">
              2
            </div>
            <div className="text-[12px] sm:text-[13px] font-extrabold border border-slate-300 dark:border-slate-800 rounded-full px-4 py-1.5 text-slate-600 dark:text-slate-300">
              Lộ trình bài học chuẩn hóa
            </div>
          </div>

          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-12 sm:mb-16">
            <h2 className="font-black text-slate-900 dark:text-white tracking-tight leading-[1.1] text-[clamp(1.75rem,5vw,3.5rem)]">
              Chương trình học Python Lớp 10
            </h2>
            <p className="text-slate-500 dark:text-slate-400 text-sm sm:text-base max-w-md font-medium">
              Thiết kế bám sát sách giáo khoa Tin học 10 (Cánh Diều, Kết nối tri thức) giúp học sinh dễ dàng đạt kết quả cao trên lớp.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 sm:gap-8">
            {/* Unit 1 */}
            <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 rounded-3xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition-all duration-300 group">
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-[#F26522] uppercase bg-[#F26522]/10 px-2.5 py-1 rounded-full border border-[#F26522]/20">Chủ đề 1</span>
                <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white mt-4 mb-2">Cú pháp & Kiểu dữ liệu cơ bản</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed">
                  Làm quen với môi trường lập trình Python, biến số, các kiểu dữ liệu cơ bản (số nguyên, số thực, xâu ký tự) và các câu lệnh nhập/xuất <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono text-xs text-[#F26522]">input()</code>, <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono text-xs text-[#F26522]">print()</code>.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-slate-200/20 flex items-center justify-between text-xs sm:text-sm font-bold text-slate-400 group-hover:text-[#F26522] transition-colors duration-300">
                <span>6 Bài học • 2 Trắc nghiệm</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
            </div>

            {/* Unit 2 */}
            <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 rounded-3xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition-all duration-300 group">
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-[#F26522] uppercase bg-[#F26522]/10 px-2.5 py-1 rounded-full border border-[#F26522]/20">Chủ đề 2</span>
                <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white mt-4 mb-2">Cấu trúc Điều kiện rẽ nhánh</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed">
                  Làm chủ tư duy logic rẽ nhánh thông qua câu lệnh <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono text-xs text-[#F26522]">if</code>, <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono text-xs text-[#F26522]">elif</code>, <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono text-xs text-[#F26522]">else</code>. Áp dụng giải các bài toán thực tế sinh động.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-slate-200/20 flex items-center justify-between text-xs sm:text-sm font-bold text-slate-400 group-hover:text-[#F26522] transition-colors duration-300">
                <span>5 Bài học • 1 Thực hành</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
            </div>

            {/* Unit 3 */}
            <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 rounded-3xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition-all duration-300 group">
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-[#F26522] uppercase bg-[#F26522]/10 px-2.5 py-1 rounded-full border border-[#F26522]/20">Chủ đề 3</span>
                <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white mt-4 mb-2">Cấu trúc Vòng lặp</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed">
                  Hiểu sâu cơ chế lặp tuần hoàn thông qua vòng lặp xác định <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono text-xs text-[#F26522]">for</code> và vòng lặp điều kiện <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono text-xs text-[#F26522]">while</code>. Thực hành vẽ hình học rực rỡ với thư viện Turtle.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-slate-200/20 flex items-center justify-between text-xs sm:text-sm font-bold text-slate-400 group-hover:text-[#F26522] transition-colors duration-300">
                <span>5 Bài học • 2 Đấu Boss</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
            </div>

            {/* Unit 4 */}
            <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 rounded-3xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition-all duration-300 group">
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-[#F26522] uppercase bg-[#F26522]/10 px-2.5 py-1 rounded-full border border-[#F26522]/20">Chủ đề 4</span>
                <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white mt-4 mb-2">Kiểu dữ liệu Danh sách (List)</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed">
                  Quản lý tập hợp nhiều dữ liệu có thứ tự. Thành thạo các thao tác duyệt mảng, thêm phần tử (<code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono text-xs text-[#F26522]">append()</code>), xóa phần tử, sắp xếp và lọc dữ liệu.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-slate-200/20 flex items-center justify-between text-xs sm:text-sm font-bold text-slate-400 group-hover:text-[#F26522] transition-colors duration-300">
                <span>4 Bài học • 1 Đề kiểm tra</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
            </div>

            {/* Unit 5 */}
            <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 rounded-3xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition-all duration-300 group">
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-[#F26522] uppercase bg-[#F26522]/10 px-2.5 py-1 rounded-full border border-[#F26522]/20">Chủ đề 5</span>
                <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white mt-4 mb-2">Hàm & Mô-đun hóa Code</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed">
                  Tìm hiểu cách tự định nghĩa hàm riêng bằng từ khóa <code className="bg-slate-100 dark:bg-slate-800 px-1 py-0.5 rounded font-mono text-xs text-[#F26522]">def</code>, tái sử dụng mã nguồn hiệu quả, truyền đối số và sử dụng các thư viện toán học tiêu chuẩn.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-slate-200/20 flex items-center justify-between text-xs sm:text-sm font-bold text-slate-400 group-hover:text-[#F26522] transition-colors duration-300">
                <span>4 Bài học • 1 Dự án cuối khoá</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
            </div>

            {/* Unit 6 */}
            <div className="liquid-glass border border-slate-200/50 dark:border-slate-800/50 rounded-3xl p-6 shadow-sm flex flex-col justify-between hover:shadow-md transition-all duration-300 group">
              <div>
                <span className="text-[10px] font-extrabold tracking-widest text-[#F26522] uppercase bg-[#F26522]/10 px-2.5 py-1 rounded-full border border-[#F26522]/20">Chủ đề 6</span>
                <h3 className="text-lg sm:text-xl font-black text-slate-900 dark:text-white mt-4 mb-2">Gỡ lỗi & Thuật toán Cơ bản</h3>
                <p className="text-slate-500 dark:text-slate-400 text-xs sm:text-sm leading-relaxed">
                  Xây dựng tư duy giải quyết vấn đề. Học cách phân loại lỗi (lỗi cú pháp, lỗi thực thi, lỗi logic), thực hành các thuật toán tìm kiếm và sắp xếp cơ bản một cách tường minh nhất.
                </p>
              </div>
              <div className="mt-6 pt-4 border-t border-slate-200/20 flex items-center justify-between text-xs sm:text-sm font-bold text-slate-400 group-hover:text-[#F26522] transition-colors duration-300">
                <span>3 Bài học • 1 Boss cuối</span>
                <ArrowRight className="w-4 h-4 transition-transform duration-300 group-hover:translate-x-1" />
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}

